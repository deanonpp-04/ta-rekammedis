<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pemeriksaan_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    // Listing all Pemeriksaan
    public function listing()
    {
        $this->db->select('pemeriksaan.*,pasien.nama_pasien,dokter.nama_dokter,diagnosa.nama_diagnosa');
        $this->db->from('pemeriksaan');
        $this->db->join('pasien','pasien.id_pasien=pemeriksaan.id_pasien', 'left');
        $this->db->join('dokter','dokter.id_dokter=pemeriksaan.id_dokter', 'left');
        $this->db->join('diagnosa','diagnosa.id_diagnosa=pemeriksaan.id_diagnosa', 'left');
        $this->db->order_by('id_periksa', 'asc');
        $query = $this->db->get();
        return $query->result();
    }


    // Detail Pemeriksaan
    public function detail($id_periksa)
    {
        $this->db->select('*');
        $this->db->from('pemeriksaan');
        $this->db->where('id_periksa', $id_periksa);
        $this->db->order_by('id_periksa', 'desc');
        $query = $this->db->get();
        return $query->row();
    }
    // login 
    /*public function login($saname,$password)
    {
        $this->db->select('*');
        $this->db->from('sa');
        $this->db->where(array('saname' =>$saname,
                                'password' =>SHA1($password)));
        $this->db->order_by('id_sa', 'desc');
        $query = $this->db->get();
        return $query->row();
    }*/
    //Function Detail
    public function detail_data($id_periksa = NULL){
        $this->db->join('pasien','pasien.id_pasien=pemeriksaan.id_pasien', 'left');
        $this->db->join('dokter','dokter.id_dokter=pemeriksaan.id_dokter', 'left');
        $this->db->join('diagnosa','diagnosa.id_diagnosa=pemeriksaan.id_diagnosa', 'left');
        $query = $this->db->get_where('pemeriksaan', array('id_periksa' =>$id_periksa))->row();
        return $query;
    }
    //Tambah
    public function create($data)
    {
        $this->db->insert('pemeriksaan', $data);
    }

    //Edit 
    public function edit($data)
    {
        $this->db->where('id_periksa', $data['id_periksa']);
        $this->db->update('pemeriksaan',$data);
    }
    //Delete
    public function delete($data)
    {
        $this->db->where('id_periksa', $data['id_periksa']);
        $this->db->delete('pemeriksaan',$data);
    }
    public function getNamaDiagnosadanTanggal($id){
    $this->db->select('nama_diagnosa,tgl_periksa');
    $this->db->from('pemeriksaan');
    $this->db->where('id_pasien',$id);
    $this->db->join('diagnosa','diagnosa.id_diagnosa = pemeriksaan.id_diagnosa');
    return $this->db->get()->row_array();
    }
}