<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Praktek_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    
    public function listing()
    {
    
        $this->db->select('*');
        $this->db->from('praktik');
        $this->db->order_by('id_praktik', 'asc');
        $query = $this->db->get();
        return $query->result();
    }

    // Detail praktik
    public function detail($id_praktik)
    {
        $this->db->select('*');
        $this->db->from('praktik');
        $this->db->where('id_praktik', $id_praktik);
        $this->db->order_by('id_praktik', 'desc');
        $query = $this->db->get();
        return $query->row();
    }
    
    //Tambah
    public function create($data)
    {
        $this->db->insert('praktik', $data);
    }

    //Edit 
    public function edit($data)
    {
        $this->db->where('id_praktik', $data['id_praktik']);
        $this->db->update('praktik',$data);
    }
    //Delete
    public function delete($data)
    {
        $this->db->where('id_praktik', $data['id_praktik']);
        $this->db->delete('praktik',$data);
    }

}