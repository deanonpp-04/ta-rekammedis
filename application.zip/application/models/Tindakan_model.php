<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tindakan_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    // Listing all Pemeriksaan
    public function listing()
    {
        $this->db->select('tindakan.*,pasien.nama_pasien,pemeriksaan.tgl_periksa,diagnosa.nama_diagnosa');
        $this->db->from('tindakan');
        $this->db->join('pasien','pasien.id_pasien=tindakan.id_pasien', 'left');
        $this->db->join('pemeriksaan','pemeriksaan.id_periksa=tindakan.id_periksa', 'left');
        $this->db->join('diagnosa','diagnosa.id_diagnosa=tindakan.id_diagnosa', 'left');
        $this->db->order_by('id_tindakan', 'asc');
        $query = $this->db->get();
        return $query->result();
    }

    // Detail Pemeriksaan
    public function detail($id_tindakan)
    {
        $this->db->select('*');
        $this->db->from('tindakan');
        $this->db->where('id_tindakan', $id_tindakan);
        $this->db->order_by('id_tindakan', 'desc');
        $query = $this->db->get();
        return $query->row();
    }
    // login 
    /*public function login($saname,$password)
    {
        $this->db->select('*');
        $this->db->from('sa');
        $this->db->where(array('saname' =>$saname,
                                'password' =>SHA1($password)));
        $this->db->order_by('id_sa', 'desc');
        $query = $this->db->get();
        return $query->row();
    }*/
    //Function Detail
    public function detail_data($id_tindakan = NULL){
        $this->db->join('pasien','pasien.id_pasien=pemeriksaan.id_pasien', 'left');
        $this->db->join('pemeriksaan','pemeriksaan.id_periksa=pemeriksaan.id_periksa', 'left');
        $this->db->join('diagnosa','diagnosa.id_diagnosa=pemeriksaan.id_diagnosa', 'left');
        $query = $this->db->get_where('tindakan', array('id_tindakan' =>$id_tindakan))->row();
        return $query;
    }
    //Tambah
    public function create($data)
    {
        $this->db->insert('tindakan', $data);
    }

    //Edit 
    public function edit($data)
    {
        $this->db->where('id_tindakan', $data['id_tindakan']);
        $this->db->update('tindakan',$data);
    }
    //Delete
    public function delete($data)
    {
        $this->db->where('id_tindakan', $data['id_tindakan']);
        $this->db->delete('tindakan',$data);
    }

}