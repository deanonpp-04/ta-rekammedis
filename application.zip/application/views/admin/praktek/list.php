<p>
    <a href="<?php echo base_url('admin/praktek/create') ?>" class="btn-success btn-sm">
        <i class="fa fa-plus"></i> Tambah Data Praktek
    </a>
</p>

<?php
//Notifikasi
if($this->session->flashdata('sukses')){
    echo '<p class="alert alert-success">';
    echo $this->session->flashdata('sukses');
    echo '</div>';
}
?>

<table class="table table-bordered" id="example1">
    <thead>
        <tr>
            <th>No</th>
            <th>Kode Praktek</th>
            <th>Nama Praktek</th>
            <th>Alamat</th>
            <th>Keterangan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $no=1; foreach($praktek as $praktek) { ?>
        <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $praktek->kd_praktik ?></td>
            <td><?php echo $praktek->nama_praktik ?></td>
            <td><?php echo $praktek->alamat ?></td>
            <td><?php echo $praktek->keterangan ?></td>
            <td>
                <a href="<?php echo base_url('admin/praktek/edit/' .$praktek->id_praktik) ?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i> Edit</a>
                <?php include('delete.php')?>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table> 