<?php
//Notifikasi error
echo validation_errors('<div class="alert-warning">','</div>');

//Form open
echo form_open(base_url('admin/praktek/create'), 'class="form-horizontal"');
?>


<div class="form-group">
    <label class="col-md-2 control-label"> Kode Praktik</label> 
    <div class="col-md-5">
        <input type="text" name="kd_praktik" class="form-control" placeholder="Kode Praktik" value="<?php echo set_value('kd_praktik') ?>" required>
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label"> Nama Praktik</label> 
    <div class="col-md-5">
        <input type="text" name="nama_praktik" class="form-control" placeholder="Nama Praktik " value="<?php echo set_value('nama_praktik') ?>" required>
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label"> Alamat </label> 
    <div class="col-md-5">
        <input type="text" name="alamat" class="form-control" placeholder="Alamat " value="<?php echo set_value('alamat') ?>" required>
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label"> Keterangan </label> 
    <div class="col-md-5">
        <input type="text" name="keterangan" class="form-control" placeholder="Keterangan " value="<?php echo set_value('keterangan') ?>" required>
    </div>
</div>


<div class="form-group">
    <label class="col-md-2 control-label"></label> 
    <div class="col-md-5">
        <button class="btn btn-success btn-xm" name="submit" type="submit">
            <i class="fa fa-save"></i> Simpan
        </button>
        <button class="btn btn-info btn-xm" name="reset" type="reset">
            <i class="fa fa-times"></i> Reset
        </button>
    </div>
</div>
<?php echo form_close(); ?>