<?php
//Notifikasi error
echo validation_errors('<div class="alert-warning">','</div>');

//Form open
echo form_open(base_url('admin/tindakan/edit/'.$tindakan->id_tindakan), 'class="form-horizontal"');
?>
<div class="form-group">
    <div class="col-md-5">
        <input type="hidden" name="id_tindakan"  class="form-control" placeholder="id tindakan" >
    </div>
</div>

<!-- <div class="form-group">
    <label class="col-md-2 control-label"> Kode tindakan</label> 
    <div class="col-md-5">
        <input type="text" name="kd_tindakan" class="form-control" placeholder="Kode tindakan " value="<?php echo $tindakan->kd_tindakan?>" required>
    </div>
</div> -->
<div class="form-group">
    <label class="col-md-2 control-label text-right">Nama Pasien</label>
        <div class="col-md-5">
            <select name="id_pasien" class="form-control" >
            
            <?php foreach($pasien as $pasien){ 
                $this->db->select('*');
                //$this->db->from('tbl_anggota');
                $db = $this->db->get_where('pasien', array('id_pasien'=>$id_pasien))->row();
                
                if($pasien->id_pasien == $id_pasien){?>
                    <option value="<?php echo $db->id_pasien?>" 
                    <?php if($pasien->id_pasien==$pasien->id_pasien) { echo "selected"; } ?>>
                            <?php echo $db->nama_pasien?>
            </option>
            
            <?php }else{ ?>
                <option value="<?php echo $pasien->id_pasien?>">
                            <?php echo $pasien->nama_pasien ?>
            <?php }
        } ?>
        
            </select>
        </div>
    </div>

    <div class="form-group">
    <label class="col-md-2 control-label text-right">Penyakit</label>
        <div class="col-md-5">
            <select name="id_diagnosa" class="form-control" >
            
            <?php foreach($diagnosa as $diagnosa){ 
                $this->db->select('*');
                //$this->db->from('tbl_anggota');
                $db = $this->db->get_where('diagnosa', array('id_diagnosa'=>$id_diagnosa))->row();
                
                if($diagnosa->id_diagnosa == $id_diagnosa){?>
                    <option value="<?php echo $db->id_diagnosa?>" 
                    <?php if($diagnosa->id_diagnosa==$diagnosa->id_diagnosa) { echo "selected"; } ?>>
                            <?php echo $db->nama_diagnosa?>
            </option>
            
            <?php }else{ ?>
                <option value="<?php echo $diagnosa->id_diagnosa?>">
                            <?php echo $diagnosa->nama_diagnosa ?>
            <?php }
        } ?>
        
            </select>
        </div>
    </div>


<div class="form-group">
    <label class="col-md-2 control-label"> Nama tindakan</label> 
    <div class="col-md-5">
        <input type="text" name="nama_tindakan" class="form-control" placeholder="Nama tindakan " value="<?php echo $tindakan->nama_tindakan?>" required>
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label"> Biaya tindakan </label> 
    <div class="col-md-5">
        <input type="text" name="biaya_tindakan" class="form-control" placeholder="Alamat " value="<?php echo $tindakan->biaya_tindakan?>" required>
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label"> Keterangan </label> 
    <div class="col-md-5">
        <input type="text" name="keterangan" class="form-control" placeholder="Keterangan " value="<?php echo $tindakan->keterangan?>" required>
    </div>
</div>


<div class="form-group">
    <label class="col-md-2 control-label"></label> 
    <div class="col-md-5">
    <button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#update-<?php echo $tindakan->id_tindakan ?>">
        <i class="fa fa-edit"></i>Update
    </button>

<div class="modal fade" id="update-<?php echo $tindakan->id_tindakan ?>">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center">EDIT DATA tindakan</h4>
        </div>
		<div class="modal-body">
			<div class="callout callout-warning">
				<h4>Peringatan!</h4>
					Yakin ingin mengubah data ini?
			</div>

        <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Tidak</button>
        <input type="submit" class="btn btn-warning" name="submit" value="Ya">
        </div>
    </div>
    <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

    </div>
</div>
<!-- <div class="form-group">
    <label class="col-md-2 control-label"></label> 
    <div class="col-md-5">
        <button class="btn btn-success btn-xm" name="submit" type="submit">
            <i class="fa fa-save"></i> Update
        </button>
    </div>
</div> -->
<?php echo form_close(); ?>