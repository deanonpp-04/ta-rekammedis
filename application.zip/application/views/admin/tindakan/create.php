<?php
//Notifikasi error
echo validation_errors('<div class="alert-warning">','</div>');

//Form open
echo form_open(base_url('admin/tindakan/create'), 'class="form-horizontal"');
?>
<!-- <div class="form-group">
    <label class="col-md-2 control-label">Tanggal Periksa  </label> 
    <div class="col-md-5">
    <input type="date" name="tgl_periksa" class="form-control" placeholder="tgl_periksa" value=<?=date('Y-m-d H:i:s ') ?> required>
    </div>
</div> -->
<input type="text" value="" id="id_periksa" name="id_periksa"> 
<div class="form-group">
    <label class="col-md-2 control-label text-right">Nama Pasien</label>
        <div class="col-md-5">
            <select name="id_pasien" class="form-control" id="pasien" >
            <option>--</option>
            <?php 
            foreach($pemeriksaan as $pasien){ 
                $this->db->select('*');
                //$this->db->from('tbl_anggota');
                $db = $this->db->get_where('pemeriksaan', array('id_pasien'=>$id_pasien))->row();
                if($pasien->id_pasien == $id_pasien){?>
                    <option value="<?php echo $db->id_pasien?>" selected>
                            <?php echo $db->nama_pasien ?>
            </option>
            <?php }else{ ?>
                <option value="<?php echo $pasien->id_pasien?>">
                <?php echo $pasien->nama_pasien ?>
            <?php }
        } ?>
            </select>
        </div>
    </div>
<!-- 
    <div class="form-group">
    <label class="col-md-2 control-label text-right">Tanggal Periksa</label>
    <div class="col-md-5">
            <select name="id_periksa" class="form-control" >
            <option>--</option>
            <?php foreach($pemeriksaan as $pemeriksaan){ 
                $this->db->select('*');
                //$this->db->from('tbl_anggota');
                $db = $this->db->get_where('pemeriksaan', array('id_periksa'=>$id_periksa))->row();
                
                if($pemeriksaan->id_periksa == $id_periksa){?>
                    <option value="<?php echo $db->id_periksa?>" selected>
                            <?php echo $db->tgl_periksa ?>
            </option>
            
            <?php }else{ ?>
                <option value="<?php echo $pemeriksaan->id_periksa?>">
                <?php echo $pemeriksaan->tgl_periksa ?>
            <?php }
        } ?>
            </select>
        </div>
    </div> -->

    <!-- <div class="form-group">
    <label class="col-md-2 control-label text-right">Nama Penyakit</label>
        <div class="col-md-5">
            <select name="id_diagnosa" class="form-control" >
            <option>--</option>
            <?php foreach($diagnosa as $diagnosa){ 
                $this->db->select('*');
                $db = $this->db->get_where('diagnosa', array('id_diagnosa'=>$id_diagnosa))->row();
                
                if($diagnosa->id_diagnosa == $id_diagnosa){?>
                    <option value="<?php echo $db->id_diagnosa?>" selected>
                            <?php echo $db->nama_diagnosa ?>
            </option>
            
            <?php }else{ ?>
                <option value="<?php echo $diagnosa->id_diagnosa?>">
                            <?php echo $diagnosa->nama_diagnosa ?>
            <?php }
        } ?>
            </select>
        </div>
    </div> -->
    <div class="form-group">
    <label class="col-md-2 control-label"> Tanggal Periksa  </label> 
    <div class="col-md-5">
        <input  type="text" name="tgl_periksa" id="tgl_periksa" class="form-control" placeholder="tgl_periksa " value="" disabled id="tgl_periksa">
    </div>
</div>

    <div class="form-group">
    <label class="col-md-2 control-label"> Nama Penyakit  </label> 
    <div class="col-md-5">
        <input  type="text" name="nama_diagnosa" id="nama_diagnosa" class="form-control" placeholder="nama_diagnosa " value="" disabled id="nama_diagnosa">
    </div>
</div>


    <div class="form-group">
    <label class="col-md-2 control-label"> Nama Tindakan  </label> 
    <div class="col-md-5">
        <input type="text" name="nama_tindakan" class="form-control" placeholder="nama_tindakan " value="<?php echo set_value('nama_tindakan') ?>" required>
    </div>
</div>


<div class="form-group">
    <label class="col-md-2 control-label"> Biaya Tindakan  </label> 
    <div class="col-md-5">
        <input type="text" name="biaya_tindakan" class="form-control" placeholder="biaya_tindakan " value="<?php echo set_value('biaya_tindakan') ?>" required>
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label">Keterangan</label> 
    <div class="col-md-5">
        <input type="text" name="keterangan" class="form-control" placeholder="Keterangan" value="<?php echo set_value('keterangan') ?>" required>
    </div>
</div>
    

<div class="form-group">
    <label class="col-md-2 control-label"></label> 
    <div class="col-md-5">
        <button class="btn btn-success btn-xm" name="submit" type="submit">
            <i class="fa fa-save"></i> Simpan
        </button>
        <button class="btn btn-info btn-xm" name="reset" type="reset">
            <i class="fa fa-times"></i> Reset
        </button>
    </div>
</div>
<?php echo form_close(); ?>
<script>
    $('#pasien').on('change',function(){
        var id = $(this).val();
        console.log(id);
        $.ajax({
            url : "<?=base_url();?>admin/Pemeriksaan/getNamaDiagnosadanTanggal",
            method : "POST",
            data : {id: id},
            async : false,
            dataType: 'json',
            success: function(data){
                
                $('#id_periksa').val(data['id_periksa']);
                $('#nama_diagnosa').val(data['nama_diagnosa']);
                $('#tgl_periksa').val(data['tgl_periksa']);
            }
        });
    })

</script>