<p>
    <a href="<?php echo base_url('admin/tindakan/create') ?>" class="btn-success btn-sm">
        <i class="fa fa-plus"></i> Tambah Data Tindakan
    </a>
</p>

<?php
//Notifikasi
if($this->session->flashdata('sukses')){
    echo '<p class="alert alert-success">';
    echo $this->session->flashdata('sukses');
    echo '</div>';
}
?>

<table class="table table-bordered" id="example1">
    <thead>
        <tr>
            <th>No</th>
            <!-- <th>Kode Tindakan</th> -->
            <th>Nama Pasien</th>
            <th>Penyakit</th>
            <th>Nama Tindakan</th>
            <th>Biaya Tindakan</th>
            <th>Keterangan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $no=1; foreach($tindakan as $tindakan) { ?>
        <tr>
            <td><?php echo $no++ ?></td>
            <!-- <td><?php echo $tindakan->kd_tindakan ?></td> -->
            <td><?php echo $tindakan->nama_pasien ?></td>
            <td><?php echo $tindakan->nama_diagnosa ?></td>
            <td><?php echo $tindakan->nama_tindakan ?></td>
            <td><?php echo $tindakan->biaya_tindakan?></td>
            <td><?php echo $tindakan->keterangan ?></td>
            <td>
                <a href="<?php echo base_url('admin/tindakan/edit/' .$tindakan->id_tindakan) ?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i> Edit</a>
                <?php include('delete.php')?>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table> 