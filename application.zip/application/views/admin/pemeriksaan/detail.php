<table class="table table-striped">

<tbody>

        <tr>
            <th scope="row">Tanggal Periksa</th>
            <td><?php echo $pemeriksaan->tgl_periksa ?></td>
        </tr>

        <tr>
            <th scope="row"> Nama Pasien</th>
            <td><?php echo $pemeriksaan->nama_pasien ?></td>
        </tr>
        <tr>
            <th scope="row"> Nama Dokter</th>
            <td><?php echo $pemeriksaan->nama_dokter ?></td>
        </tr>

        <tr>
            <th scope="row"> Keluhan </th>
            <td><?php echo $pemeriksaan->keluhan ?></td>
        </tr>

        <tr>
            <th scope="row">Nama Penyakit</th>
         
            <td><?php echo $pemeriksaan->nama_diagnosa ?></td>
        </tr>

        <tr>
            <th scope="row"> Biaya Periksa</th>
            <td><?php echo $pemeriksaan->biaya_periksa ?></td>
        </tr>

        <tr>
            <th scope="row"> Keterangan</th>
            <td><?php echo $pemeriksaan->keterangan ?></td>
        </tr>
    


    </tr>
    <tr>
        <td>
      <a href="<?php echo base_url('admin/pemeriksaan') ?>" class="btn btn-success btn-xs"> Kembali</a></td>
    </tr>
</tbody>
</table>

 