  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">

        <li class="header">MAIN NAVIGATION</li>
        <!-- menu dasbord -->
          <li><a href="<?php echo base_url('admin/dasbor') ?>";"><i class="fa fa-circle-o text-aqua"></i> <span>Dasbord</span></a></li>
            <!--  menu user-->
            <li><a href="<?php echo base_url('admin/user') ?>">  <i class="fa fa-lock"></i> <span>USER</span></a></li>
            
              <!-- <li><a href="<?php echo base_url('admin/praktek') ?>"><i class="fa fa-hospital-o" style="font-size:20px"></i><span>Data Praktik</span></a></li> -->
              <li><a href="<?php echo base_url('admin/dokter') ?>">  <i class="fa fa-user-md" style="font-size:24px"></i> <span>Data Dokter</span></a></li>
              <li><a href="<?php echo base_url('admin/pasien') ?>">  <i class="fa fa-group" style="font-size:20px"></i> <span>Data Pasien</span></a></li>
              <li><a href="<?php echo base_url('admin/pemeriksaan') ?>">  <i class="fa fa-stethoscope" style="font-size:24px"></i> <span>Data Pemeriksaan</span></a></li> 
              <li><a href="<?php echo base_url('admin/diagnosa') ?>">  <i class="fa fa-th" style="font-size:20px"></i> <span>Data Diagnosa</span></a></li>
              <li><a href="<?php echo base_url('admin/tindakan') ?>">  <i class="fa fa-medkit" style="font-size:20px"></i> <span>Data Tindakan</span></a></li>  
              <li><a href="<?php echo base_url('admin/obat') ?>">  <i class="fa fa-glass" style="font-size:20px"></i> <span>Data Obat</span></a></li>
              <li><a href="<?php echo base_url('admin/pembayaran') ?>">  <i class="fa fa-paypal" style="font-size:20px"></i> <span>Data Pembayaran</span></a></li>  
              <li><a href="<?php echo base_url('admin/remdik') ?>">  <i class="fa fa-wpforms" style="font-size:20px"></i> <span>Data Rekam Medis</span></a></li>
              <li><a href="<?php echo base_url('admin/antrian') ?>">  <i class="fa fa-hourglass-1" style="font-size:20px"></i> <span>Data Antrian</span></a></li>
              <li><a href="<?php echo base_url('admin/setting') ?>">  <i class="fa fa-cogs" style="font-size:20px"></i> <span>SETTINGS</span></a></li> 
              <li class="treeview">
              <a href="#">
                <i class="fa fa-save" style="font-size:20px"></i> <span>Data Laporan</span>
                  <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
                  </span>
              </a> 
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url('admin/laporan') ?>"><i class="fa fa-file-text-o"></i> Laporan Rekam Medis</a></li>
                <li><a href="<?php echo base_url('admin/laporan') ?>"><i class="fa fa-file-text-o"></i> Laporan Pendapatan</a></li>
              </ul>
            </li>
      </ul>
      </section>
      <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php  echo $title?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body">