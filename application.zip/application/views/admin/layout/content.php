<?php  
if ($isi) {
	# code...
	$this->load->view($isi);
}