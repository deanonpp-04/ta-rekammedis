<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
* 
*/
class Praktek extends CI_Controller
{
	//load model
    public function __construct()
	{
		parent::__construct();
		$this->load->model('praktek_model');
		//proteksi halaman
       // $this->simple_login->cek_login();
	}
	public function index()
	{
        $praktek = $this->praktek_model->listing();

        $data=array('title'=>'Data Praktek',
            'praktek' => $praktek,
			'isi' =>'admin/praktek/list');
		$this->load->view('admin/layout/wrapper',$data,FALSE);
    }
    public function create()
    {
         //Validasi input
        $valid = $this->form_validation;

        $valid->set_rules('kd_praktik','Kode Praktek','required',
        array('required' => '%s harus diisi'));

        if($valid->run()==FALSE){
         //End Validasi
        $data = array('title'   => 'Tambah Praktek',
                    'isi'     => 'admin/praktek/create');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
         //Masuk database
        }else{
            $i = $this->input;
            $data = array(  
                            'kd_praktik'=> $i->post('kd_praktik'),
                            'nama_praktik'=>$i->post('nama_praktik'),
                            'alamat'=>$i->post('alamat'),
                            'keterangan'=>$i->post('keterangan')
                        );
            $this->praktek_model->create($data);
            $this->session->set_flashdata('sukses', 'Data telah ditambah');
            redirect(base_url('admin/praktek'),'refresh');
        }
         //End masuk database
    }
    public function edit($id_praktik)
    {   
        $praktek = $this->praktek_model->detail($id_praktik);

        //Validasi input
        $valid = $this->form_validation;

        $valid->set_rules('kd_praktik','Kode praktek ','required',
            array('required' => '%s harus diisi'
            ));

        if($valid->run()==FALSE){
        //End Validasi
        $data = array('title'   => 'Edit Praktek',
                    'praktek' => $praktek,
                    'isi'     => 'admin/praktek/edit');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
        //Masuk database
        }else{
            $i = $this->input;
            $data = array(  'id_praktik'=>$id_praktik,
                            'kd_praktik'=> $i->post('kd_praktik'),
                            'nama_praktik'=>$i->post('nama_praktik'),
                            'alamat'=>$i->post('alamat'),
                            'keterangan'=>$i->post('keterangan')
                        );
            $this->praktek_model->edit($data);
            $this->session->set_flashdata('sukses', 'Data telah diubah');
            redirect(base_url('admin/praktek'),'refresh');
        }
        //End masuk database
    }

    //Delete data praktek
    public function delete($id_praktik)
    {
        $data = array('id_praktik' => $id_praktik);
        $this->praktek_model->delete($data);
        $this->session->set_flashdata('sukses', 'Data telah dihapus');
        redirect(base_url('admin/praktek'),'refresh');
    }
}