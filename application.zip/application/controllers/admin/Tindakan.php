<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tindakan extends CI_Controller {


public function __construct()
    {
        parent::__construct();
        $this->load->model('tindakan_model');
        $this->load->model('pasien_model');
        $this->load->model('pemeriksaan_model');
        $this->load->model('diagnosa_model');

    }

    // Data pemeriksaan
    public function index()
    {
        $tindakan = $this->tindakan_model->listing();

        $data = array('title'   => 'Data Tindakan',
                    'tindakan' => $tindakan,
                    'isi'     => 'admin/tindakan/list');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    // Tambah pemeriksaan
    public function create()
    {   
        //Validasi input
        $valid = $this->form_validation;
        $pasien=$this->pasien_model->listing();
        $pemeriksaan=$this->pemeriksaan_model->listing();
        // $diagnosa=$this->diagnosa_model->listing();
        $pemeriksaan_json = json_encode($pemeriksaan);
        $valid->set_rules('nama_tindakan','Nama Tindakan ','required',
            array('required' => '%s harus diisi'
            ));

        if($valid->run()==FALSE){
        //End Validasi
        $data = array('title'   => 'Tambah Tindakan',
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'pemeriksaan' => $pemeriksaan,
                    'id_periksa' => "",
                    // 'diagnosa' => $diagnosa,
                    // 'id_diagnosa' => "",
                    'isi'     => 'admin/tindakan/create');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
        //Masuk database
        }else{
            $i = $this->input;
            $data = array(  
                            'id_pasien'=> $i->post('id_pasien'),
                            'id_periksa'=> $i->post('id_periksa'), 
                            'id_diagnosa'=> $i->post('id_diagnosa'),
                            'nama_tindakan'=> $i->post('nama_tindakan'),
                            'biaya_tindakan'=> $i->post('biaya_tindakan'),
                            'keterangan'=> $i->post('keterangan'),
                        );
            $this->tindakan_model->create($data);
            $this->session->set_flashdata('sukses', 'Data telah ditambah');
            redirect(base_url('admin/tindakan'),'refresh');
        }
        //End masuk database
        $data = array('title'   => 'Tambah Tindakan',
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'periksa' => $pemeriksaan,
                    // 'id_periksa' => "",
                    // 'diagnosa' => $diagnosa,
                    'id_periksa' => "",
                    'isi'     => 'admin/tindakan/create');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    // Edit tindakan
    public function edit($id_tindakan)
    {   

        $tindakan = $this->tindakan_model->detail($id_tindakan);

        //Validasi input
        $valid = $this->form_validation;
        $pasien=$this->pasien_model->listing();
        $pemeriksaan=$this->pemeriksaan_model->listing();
        $diagnosa=$this->diagnosa_model->listing();
        

    $valid->set_rules('nama_tindakan','Nama Tindakan ','required',
            array('required' => '%s harus diisi'
            ));

        if($valid->run()==FALSE){
        //End Validasi
        $data = array('title'   => 'Edit Tindakan',
                    'tindakan' => $tindakan,
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'pemeriksaan' => $pemeriksaan,
                    'id_periksa' => "",
                    // 'diagnosa' => $diagnosa,
                    // 'id_diagnosa' => "",
                    'isi'     => 'admin/tindakan/edit');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
        //Masuk database
        }else{
            $i = $this->input;
            $data = array(  'id_tindakan'=> $id_tindakan,
                            'id_pasien'=> $i->post('id_pasien'),
                            'id_periksa'=> $i->post('id_periksa'),
                            'id_diagnosa'=> $i->post('id_periksa'),
                            'nama_tindakan'=> $i->post('nama_tindakan'),
                            'biaya_tindakan'=> $i->post('biaya_tindakan'),
                            'keterangan'=> $i->post('keterangan'),
                        );

            $this->tindakan_model->edit($data);
            $this->session->set_flashdata('sukses', 'Data telah diubah');
            redirect(base_url('admin/tindakan'),'refresh');
        }
        //End masuk database
        $data = array('title'   => 'Edit tindakan',
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'pemeriksaan' => $pemeriksaan,
                    'id_periksa' => "",
                    // 'diagnosa' => $diagnosa,
                    // 'id_diagnosa' => "",
                    'isi'     => 'admin/tindakan/edit');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    public function detail_data($id_tindakan){
    $tindakan = $this->tindakan_model->detail_data($id_tindakan);
    $pasien = $this->pasien_model->listing();
    $pemeriksaan = $this->pemeriksaan_model->listing();
    $diagnosa = $this->diagnosa_model->listing();
    $this->load->model('tindakan_model');

    $data = array('title'   => 'Detail Tindakan',
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'pemeriksaan' => $pemeriksaan,
                    'id_periksa' => "",
                    'diagnosa' => $diagnosa,
                    'diagnosa' => "",
                    'isi'     => 'admin/tindakan/detail');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }


    //Delete data tindakan
    public function delete($id_tindakan)
    {
        $data = array('id_tindakan' => $id_tindakan);
        $this->tindakan_model->delete($data);
        $this->session->set_flashdata('sukses', 'Data telah dihapus');
        redirect(base_url('admin/tindakan'),'refresh');
    }

    // public function getNamaDiagnosa(){
    //     $nama_pasien = $this->input->post('nama_pasien');
    //     $namaDiagnosa = $this->pemeriksaan->getNamaDiagnosa($nama_pasien);
    //     echo $namaDiagnosa;
    // }
}