<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
* 
*/
class Setting extends CI_Controller
{
	//load model
    public function __construct()
	{
		parent::__construct();
		$this->load->model('setting_model');
		//proteksi halaman
       // $this->simple_login->cek_login();
	}
	public function index()
	{
        $setting = $this->setting_model->listing();

        $data=array('title'=>'Data Setting',
            'setting' => $setting,
			'isi' =>'admin/setting/list');
		$this->load->view('admin/layout/wrapper',$data,FALSE);
    }
    public function create()
    {   
       
        //Validasi input
        $valid = $this->form_validation;

        $valid->set_rules('nama_praktik','nama_praktik','required',
            array('required' => '%s harus diisi'
            ));

        if($valid->run()){
              $config['upload_path'] ='./assets/upload/logo/';
            $config['allowed_types'] ='|jpg|pdf|doc|docx';

             $this->load->library('upload',$config);
             if ( ! $this->upload->do_upload('logo')){
        //End Validasi
        $data = array('title'   => 'Tambah praktek',
                       'error'   => $this->upload->display_errors(),
                 
                      'isi'     => 'admin/setting/create');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
        //Masuk database
        }else{
             $upload_file = array('upload_data' => $this->upload->data());
                 //create thumbnail gambar
                 $config['image_library'] = 'gd2';
                 $config['source_image'] = './assets/upload/logo/'.$upload_file['upload_data']['file_name'];
                 //lokasi folder thumbnail
                // $config['new_image'] = './assets/upload/image/thumbs/';
                 $config['create_thumb'] = TRUE;
                 $config['maintain_ratio'] = TRUE;
                 $config['encrypt_name']            = TRUE;
                 $config['max_size']         = 100;
                 $config['width']         = 250;
                 $config['height']       = 250;
                $config['thumb_marker'] = '';

             $this->load->library('image_lib', $config);

             $this->image_lib->resize();
             //end create thumbnail
            $i = $this->input;
            $data = array(  'id_setting'=> $i->post('id_setting'),
                            'nama_praktik'=>$i->post('nama_praktik'),
                            'logo'=> $upload_file['upload_data']['file_name'],
            				'no_telp'=> $i->post('no_telp'),
                            'email'=> $i->post('email'),
                            'alamat'=> $i->post('alamat'),
                            'keterangan'=> $i->post('keterangan')
                          
                        );
            $this->setting_model->create($data);
            $this->session->set_flashdata('sukses', 'Data telah ditambah');
            redirect(base_url('admin/setting'),'refresh');

        }}
        //End masuk database
         $data = array('title'   => 'Tambah Data Service Acceptance',
                        
                      'logo' =>"",
            //'error'   => $this->upload->display_errors(),
                      'isi'     => 'admin/setting/create');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    public function edit($id_setting)
    {   
        $setting = $this->setting_model->detail($id_setting);

        //Validasi input
        $valid = $this->form_validation;

        $valid->set_rules('nama_praktik','Nama Praktik ','required',
            array('required' => '%s harus diisi'
            ));

        if($valid->run()==FALSE){
        //End Validasi
        $data = array('title'   => 'Edit Praktek',
                    'setting' => $setting,
                    'isi'     => 'admin/setting/edit');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
        //Masuk database
        }else{
            $i = $this->input;
            $data = array(  'id_setting'=>$id_setting,
                        'nama_praktik'=> $i->post('nama_praktik'),
                        'logo'=>$i->post('logo'),
                        'no_telp'=>$i->post('no_telp'),
                        'email'=>$i->post('email'),
                        'alamat'=>$i->post('alamat'),
                        'keterangan'=>$i->post('keterangan')
                        );
            $this->setting_model->edit($data);
            $this->session->set_flashdata('sukses', 'Data telah diubah');
            redirect(base_url('admin/setting'),'refresh');
        }
        //End masuk database
    }

    //Delete data praktek
    public function delete($id_setting)
    {
        $data = array('id_setting' => $id_setting);
        $this->setting_model->delete($data);
        $this->session->set_flashdata('sukses', 'Data telah dihapus');
        redirect(base_url('admin/setting'),'refresh');
    }
}