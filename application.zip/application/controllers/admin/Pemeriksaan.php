<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pemeriksaan extends CI_Controller {


public function __construct()
    {
        parent::__construct();
        $this->load->model('pemeriksaan_model');
        $this->load->model('pasien_model');
        $this->load->model('dokter_model');
        $this->load->model('diagnosa_model');

    }

    // Data pemeriksaan
    public function index()
    {
        $pemeriksaan = $this->pemeriksaan_model->listing();

        $data = array('title'   => 'Data Pemeriksaan',
                    'pemeriksaan' => $pemeriksaan,
                    'isi'     => 'admin/pemeriksaan/list');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    // Tambah pemeriksaan
    public function create()
    {   
        //Validasi input
        $valid = $this->form_validation;
        $pasien=$this->pasien_model->listing();
        $dokter=$this->dokter_model->listing();
        $diagnosa=$this->diagnosa_model->listing();

        $valid->set_rules('keluhan','Tanggal Periksa ','required',
            array('required' => '%s harus diisi'
            ));

        if($valid->run()==FALSE){
        //End Validasi
        $data = array('title'   => 'Tambah Pemeriksaan',
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'dokter' => $dokter,
                    'id_dokter' => "",
                    'diagnosa' => $diagnosa,
                    'id_diagnosa' => "",
                    'isi'     => 'admin/pemeriksaan/create');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
        //Masuk database
        }else{
            $i = $this->input;
            $data = array(  
                            'tgl_periksa'=> date('Y-m-d H:i:s'),
                            'id_pasien'=> $i->post('id_pasien'),
                            'id_dokter'=> $i->post('id_dokter'),
                            'keluhan'=> $i->post('keluhan'),
                            'id_diagnosa'=> $i->post('id_diagnosa'),
                            'biaya_periksa'=> $i->post('biaya_periksa'),
                            'keterangan'=> $i->post('keterangan'),
                        );
            $this->pemeriksaan_model->create($data);
            $this->session->set_flashdata('sukses', 'Data telah ditambah');
            redirect(base_url('admin/pemeriksaan'),'refresh');
        }
        //End masuk database
        $data = array('title'   => 'Tambah Pemeriksaan',
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'dokter' => $dokter,
                    'id_dokter' => "",
                    'diagnosa' => $diagnosa,
                    'id_diagnosa' => "",
                    'isi'     => 'admin/pemeriksaan/create');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    // Edit pemeriksaan
    public function edit($id_periksa)
    {   
     
        $pemeriksaan = $this->pemeriksaan_model->detail($id_periksa);

        //Validasi input
        $valid = $this->form_validation;
        $pasien=$this->pasien_model->listing();
        $dokter=$this->dokter_model->listing();
        $diagnosa=$this->diagnosa_model->listing();

    $valid->set_rules('tgl_periksa','Tanggal Periksa ','required',
            array('required' => '%s harus diisi'
            ));

        if($valid->run()==FALSE){
        //End Validasi
        $data = array('title'   => 'Edit Pemeriksaan',
                    'pemeriksaan' => $pemeriksaan,
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'dokter' => $dokter,
                    'id_dokter' => "",
                    'diagnosa' => $diagnosa,
                    'id_diagnosa' => "",
                    'isi'     => 'admin/pemeriksaan/edit');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
        //Masuk database
        }else{
            $i = $this->input;
            $data = array(  'id_periksa'=> $id_periksa,
                    'tgl_periksa'=> $i->post('tgl_periksa'),
                    'id_pasien'=> $i->post('id_pasien'),
                    'id_dokter'=> $i->post('id_dokter'),
                    'keluhan'=> $i->post('keluhan'),
                    'id_diagnosa'=> $i->post('id_diagnosa'),
                    'biaya_periksa'=> $i->post('biaya_periksa'),
                    'keterangan'=> $i->post('keterangan'),        
                        );

            $this->pemeriksaan_model->edit($data);
            $this->session->set_flashdata('sukses', 'Data telah diubah');
            redirect(base_url('admin/pemeriksaan'),'refresh');
        }
        //End masuk database
        $data = array('title'   => 'Edit pemeriksaan',
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'dokter' => $dokter,
                    'id_dokter' => "",
                    'diagnosa' => $diagnosa,
                    'id_diagnosa' => "",
                    'isi'     => 'admin/pemeriksaan/edit');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    public function detail_data($id_periksa){
    $pemeriksaan = $this->pemeriksaan_model->detail_data($id_periksa);
    $pasien = $this->pasien_model->listing();
    $dokter=$this->dokter_model->listing();
    $diagnosa=$this->diagnosa_model->listing();
    $this->load->model('pemeriksaan_model');

    $data = array('title'   => 'Detail Pemeriksaan',
                    'pasien' => $pasien,
                    'id_pasien' => "",
                    'dokter' => $dokter,
                    'id_dokter' => "",
                    'diagnosa' => $diagnosa,
                    'id_diagnosa' => "",
                    'isi'     => 'admin/pemeriksaan/detail');
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }


    //Delete data surat
    public function delete($id_periksa)
    {
        $data = array('id_periksa' => $id_periksa);
        $this->pemeriksaan_model->delete($data);
        $this->session->set_flashdata('sukses', 'Data telah dihapus');
        redirect(base_url('admin/pemeriksaan'),'refresh');
    }

    public function detail2($id_periksa){
        $pemeriksaan = $this->pemeriksaan_model->detail_data($id_periksa);
        $pasien = $this->pasien_model->listing();
        $dokter=$this->dokter_model->listing();
        $diagnosa=$this->diagnosa_model->listing();
        $this->load->model('pemeriksaan_model');
    
        $data = array('title'   => 'Detail Pemeriksaan',
        'pemeriksaan'=>$pemeriksaan,
                        'pasien' => $pasien,
                        'id_pasien' => "",
                        'dokter' => $dokter,
                        'id_dokter' => "",
                        'diagnosa' => $diagnosa,
                        'id_diagnosa' => "",
                        'isi'     => 'admin/pemeriksaan/detail');
            $this->load->view('admin/layout/wrapper', $data, FALSE);


    }
    public function getNamaDiagnosadanTanggal(){
        $id = $this->input->post('id');
        $diagnosa = $this->pemeriksaan_model->getNamaDiagnosadanTanggal($id);
        echo json_encode($diagnosa);
    }
}